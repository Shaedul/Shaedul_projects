jwerty.key('f1', function () {
	window.location = document.getElementById('RegistrationLink').href;
});
jwerty.key('f2', function () {
	window.location = document.getElementById('AdmissionLink').href;
});