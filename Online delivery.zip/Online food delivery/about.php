<html>
<div><br/><center><h2><font face="Lucida Handwriting" size="+1" color="#00CCFF">ABOUT US</font></h2></center></div>
<div style="width:100%;float:left">
<div>
  <p><br/>

	 <span> <div id="Name"><span class="blue"><font color="red">D</font></span><span>elicious</span>&nbsp;<span class="blue"><font color="red">F</font></span><span>ood</span> </div>
<div id="Informations"><span>Latest trends in Food</span></div></span>
</div>
	  <div>
	  <p align="justify">

	     <b> Who we are?</b></br></br></br>

Hungrynaki.com is a 100% Chittagong Online Food Ordering and Delivery Service launched in 2013 to deliver your cravings at your doorsteps. We are passionate about food and are always prompt to deliver whenever the radar blips hungry. Come rain, heat and storm our delivery team will be at your doorstep with a bright smile and holding the food you have been craving, intact through our insulated boxes!

</br></br></br><b>Our purpose</b><br></br>

We just don�t want you to be hungry.
A hungry (wo)man is an angry (wo)man. HungryNaki gives you another reason to be stress-free in life. We don�t want you to sweat in the kitchen to waste your valuable pastime after a long day of work.
So here we are, helping you find the right restaurant, caf� or any other eatery in your neighborhood to order their food online via our website. The country is already taking a high blood pressure toll. We are here to soothe your hearts simply by lightening up your rumbling stomachs.
Right now we�re capturing the hearts of people living in a limited amount of areas in Dhaka, Chittagong and Sylhet (we cover pretty much all the major areas, though). Don�t be disheartened if we can�t provide service in the area you�re living in just yet, we�re working on capturing your hearts too.
	  </p>
	 </div>
	  </div>
	  </div>
	  </html>
