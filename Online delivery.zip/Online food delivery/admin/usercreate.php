<center><fieldset style='width:60%'><table border='0'>

    	<tr><td>User Name</td>
	<td>Password</td></tr>
    <?php
include("config.php");
$sel=mysql_query("select * from details");
while($arr=mysql_fetch_array($sel))
  {
     $i=$arr['name'];

	echo "






	<tr>

	<td>".$arr['name']."</td>
	 <td>".$arr['pass']."</td>

</tr>
";
}


	?>

	</table>
<br>

</fieldset>
</center>






<?php
session_start();
$name=$_SESSION['eid'];
include("config.php");

$catg=$_REQUEST['cat'];
$subcatg=$_REQUEST['subcat'];
$img=$_FILES['file']['tmp_name'];
$name=$_REQUEST['t1'];
$pass=$_REQUEST['t2'];
$desc=$_REQUEST['text'];
$t=date("d-m-y h-i-s");

if($_REQUEST['sub'])
  {
    if(mysql_query("insert into details  values('$name','$pass') "))
	   {


	    echo "<font size='+2'>User Created successfully</font>";
		}
	else
	 {
	   echo "User  is not inserted";
	   }
	}


?><head>
<script>
function showUser(str)
{
if (str=="")
{
document.getElementById("txtHint").innerHTML="";
return;
}

if (window.XMLHttpRequest)
{// code for IE7+, Firefox, Chrome, Opera, Safari
xmlhttp=new XMLHttpRequest();
}
else
{// code for IE6, IE5
xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
}



xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
document.getElementById("subcat").innerHTML=xmlhttp.responseText;
}
}
xmlhttp.open("GET","dd.php?q="+str,true);
xmlhttp.send();
}
</script>

</head>


<style type="text/css">
<!--
.style3 {font-size: 18px; font-weight: bold; }
-->
</style>
<body>
<br><br><br>
<center><font color="#660066" size="+3">Add User</font></center>
<br><br>
<center><fieldset style="width:50%">
<form  name="testform" method="post" enctype="multipart/form-data" >
<table align="center">




  <td><span class="style3">User Name: </span></td>
  <td><label>
    <input name="t1" type="text" id="t1">
  </label></td>
</tr>
<tr>
  <td><span class="style3">Password:</span></td>
  <td><label>
  <input name="t2" type="text" id="t2">
  </label></td>
</tr>

<tr><td  colspan="2" align="center"><input name="sub" type="submit" value="Submit"></td></tr>
</table>
</form>
</fieldset></center>
</body>
