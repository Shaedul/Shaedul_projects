<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cz">


<head>
   <meta http-equiv="Content-language" content="cs">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="description" content=" ">
<meta name="keywords" content=" ">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" href="favicon.ico" type="image/x-icon">
<meta name="author" content="Kl?ra Frolichov?, Sunlight webdesign">
<meta name="Copyright" content="Kl?ra Frolichov?, Sunlight webdesign 2007">
<meta name="design" content="Sunlight webdesign - http://www.sunlight.cz, info@sunlight.cz">
<link rel="stylesheet" type="text/css" href="default.css" title="default">
</head>
<body>



<center>


<div id="Name"><span class="blue"><font color="red">D</font></span><span>elicious</span>&nbsp;<span class="blue"><font color="red">F</font></span><span>ood</span> </div>
<div id="Informations"><span>Latest trends in Food</span></div></center>





<?php
include("config.php");




if($_SERVER["REQUEST_METHOD"]=="POST")
{
$id = $_POST['id'];

if(empty($id)){echo"Enter the order No";}
else{echo"        ";}}













$sel=mysql_query("select * from orders where order_no='".$id."'");
$ed=mysql_query("update orders SET status='Passed' where order_no='".$id."'");
while($arr=mysql_fetch_array($sel))
  {
     $i=$arr['itemno'];

	echo "<center><fieldset style='width:60%'><table border='0'>
	<tr>
	<td><img src='itempics/$i.jpg' width=200 height=200></td>
	<td><h3>Product Details:</h3><b>Product:</b> ".$arr['pname']."<br>
	<b>Item No:</b> ".$arr['itemno']."<br>
	<b>Price:</b> ".$arr['price']."<br>
	<b>Size:</b> ".$arr['size']."<br></td>

	<td><h3>Buyer Details:</h3><b>Buyer:</b>  ".$arr['uname']."<br>
	<b>Account No:</b> ".$arr['ac_no']."<br>
	<b>Mobile No:</b> ".$arr['mob_no']."<br>
	<b>Address:</b> ".$arr['add']."<br>
	<b>Bank:</b> ".$arr['bank']."<br>
	<b>City:</b> ".$arr['city']."<br>
	<b>Order No:</b> ".$arr['order_no']."<br></td>
	</tr>

	</table>
</fieldset><br>
</center>";
}


	?><button onclick="myFunction()">Print_Memo</button>



<script>
function myFunction() {
    window.print();
}
</script></body></html>
