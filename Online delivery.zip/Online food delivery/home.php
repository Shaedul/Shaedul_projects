<head>
<script>
function abc()
{
var arr=new Array("usepics/party 4.jpg","usepics/party 1.jpg","usepics/ban5d.jpg","usepics/party 2.jpg","usepics/party 3.jpg");
var ind=eval(document.f1.h1.value);
document.img.src=arr[ind];
document.f1.h1.value=ind+1;
if(document.f1.h1.value==5)
{
document.f1.h1.value=0;
}
}
setInterval("abc()",3000);
</script>
</head>
<body>
<div id="RightPart">
  <div id="Page"><img src="usepics/food.png" alt="" width="669" height="210" name="img"/>
  <form name="f1">
  <input type="hidden" name="h1" value="0" />
  </form>
  <div><br/><center><h2><font face="Lucida Handwriting"  color="#00CCFF">Order Online From Your Favorite Restaurants</font></h2></center></div>
 <table border="0">
 <tr><td>
<img src="usepics/delevery.jpg" width="180" height="180"/>
</td>
<td colspan="2">
<font face="Lucida Handwriting" size="+1" color="#99CC33">
Corrugated Modernist Christian Dior Couture</font><br>
<font face="Comic Sans MS"><strong><p align="justify">Are you hungry? Had a long and stressful day? How about ordering a cheesy pizza from home or office? Then Delicious Food Bangladesh is the right destination for you! Delicious Food offers you a long and detailed list of the best restaurants and local favorites near you, to satisfy your hunger and thirst with the best online food delivery service.</p></strong></font></td>
</tr>
<tr>
<!-- <td>
<br>
<img src="usepics/news2.jpg" /><br>
<font  color="#FF66CC" face="Lucida Handwriting">Dulhan ke poshak</font><br>
<font face="Comic Sans MS"><strong>Dec 18, 2009<br>
Gone are the gathered umbrella ghagras and cholis and in their place a new fusion look for wedding wear has emerged. ...</strong></font></td>

<td>
<img src="usepics/news3.jpg" /><br>
<font  color="#FF66CC" face="Lucida Handwriting">The Tarun Tahiliani Bridal Couture Exposition 2011 </font><br>

<font face="Comic Sans MS"><strong>Jun 15, 2011<br>
The Tarun Tahiliani Bridal Couture Exposition is back with its third season of luxurious exposition, scheduled across July and August, 2011...</strong></font></td>
<td>
<img src="usepics/news4.jpg" /><br>
<font  color="#FF66CC" face="Lucida Handwriting">Neeru Kumar to open WLIFW Fall/Winter 2011 </font><br>

<font face="Comic Sans MS"><strong>Mar 30, 2011<br>     <td width="300" >
<img src="usepics/about.png" />
For the Grand Opening of WLIFW Fall/Winter 2011, Neeru Kumar has chosen to pay homage to the best of Indian fabric traditions. ...</strong></font></td></tr>
--></br>
<table><tr><td></br></br>
    <center><h2><font face="Lucida Handwriting"  color="#00CCFF">

    Our Top Partner Restaurants</font></h2></center>
</br></br></br></br>
<marquee behavior="scroll"  dir="ltr" align="absbottom"><img src="usepics/1.jpg" width="100" height="70"/>
<img src="usepics/2.png" width="100" height="70"/>
<img src="usepics/3.jpg" width="100" height="70"/><img src="usepics/11.jpg" width="100" height="70"/><img src="usepics/5.jpg" width="100" height="70"/>
<img src="usepics/6.png" width="100" height="70"/>
<img src="usepics/7.jpg" width="100" height="70"/>

<img src="usepics/8.jpg" width="100" height="70"/> <img src="usepics/9.png" width="100" height="70"/>
<img src="usepics/10.png" width="100" height="70"/> <img src="usepics/11.jpg" width="100" height="70"/><img src="usepics/4.jpg" width="100" height="70"/><img src="usepics/13.jpg" width="100" height="70"/>
</marquee>
</td></tr></table>
</table>
  </div>
  </div>
  </body>
